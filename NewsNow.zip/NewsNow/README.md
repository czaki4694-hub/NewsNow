# أخبار الآن (NewsNow)

تطبيق أخبار متنوعة بدون إعلانات مع إشعارات للأخبار العاجلة. يعتمد على RSS فقط (بدون مفاتيح API).
يُبنى تلقائياً عبر GitHub Actions: حمّل الـ APK من Actions → Artifacts أو من Releases.
لإضافة مصدر جديد عدّل الملف `data/Feeds.kt`.
