package com.example.newsnow.ui

import android.content.Context
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.newsnow.data.Article
import com.example.newsnow.data.Feeds
import com.example.newsnow.data.timeAgo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsScreen(vm: NewsViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("news", Context.MODE_PRIVATE) }
    var notify by remember { mutableStateOf(prefs.getBoolean("notify", true)) }
    val uri = LocalUriHandler.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "أخبار الآن", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f),
                    )
                    Text("إشعارات العاجل", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = notify, onCheckedChange = {
                        notify = it
                        prefs.edit().putBoolean("notify", it).apply()
                    })
                }
                ScrollableTabRow(
                    selectedTabIndex = s.tab, edgePadding = 8.dp,
                    containerColor = Color.Transparent, divider = {},
                ) {
                    Feeds.categories.forEachIndexed { i, c ->
                        Tab(selected = s.tab == i, onClick = { vm.select(i) }, text = { Text(c.title) })
                    }
                }
            }
        },
    ) { pad ->
        PullToRefreshBox(
            isRefreshing = s.loading && s.items.isNotEmpty(),
            onRefresh = { vm.load(true) },
            modifier = Modifier.padding(pad),
        ) {
            when {
                s.items.isEmpty() && s.loading -> Skeleton()
                s.items.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(s.error ?: "لا توجد أخبار", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.load(true) }) { Text("إعادة المحاولة") }
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(bottom = 48.dp)) {
                    if (s.tab == 0) item { BreakingStrip(s.items.take(6)) { uri.openUri(it.link) } }
                    itemsIndexed(s.items, key = { _, a -> a.link }) { i, a ->
                        NewsCard(a, big = i == 0 && a.image != null) { uri.openUri(a.link) }
                    }
                }
            }
        }
    }
}

@Composable
private fun BreakingStrip(items: List<Article>, onClick: (Article) -> Unit) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "عاجل", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text("آخر العناوين", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(items, key = { it.link }) { a ->
                Column(
                    Modifier.width(250.dp).clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onClick(a) }.padding(12.dp)
                ) {
                    Text(a.title, maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text("${a.source} • ${timeAgo(a.time)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun Meta(a: Article) {
    Text(
        listOf(a.source, timeAgo(a.time)).filter { it.isNotBlank() }.joinToString(" • "),
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun NewsCard(a: Article, big: Boolean, onClick: () -> Unit) {
    val ph = MaterialTheme.colorScheme.surfaceVariant
    if (big) {
        Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(bottom = 8.dp)) {
            AsyncImage(
                model = a.image, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(ph),
            )
            Column(Modifier.padding(16.dp)) {
                Text(a.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Meta(a)
            }
        }
    } else {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(a.title, style = MaterialTheme.typography.titleMedium,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (a.summary.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(a.summary, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(6.dp))
                Meta(a)
            }
            if (a.image != null) AsyncImage(
                model = a.image, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(100.dp, 72.dp).clip(RoundedCornerShape(8.dp)).background(ph),
            )
        }
    }
}

@Composable
private fun Skeleton() {
    val a by rememberInfiniteTransition(label = "sk").animateFloat(
        0.35f, 0.9f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a"
    )
    val c = MaterialTheme.colorScheme.surfaceVariant
    Column(Modifier.alpha(a)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(c))
        Spacer(Modifier.height(12.dp))
        repeat(5) {
            Row(Modifier.padding(16.dp, 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(4.dp)).background(c))
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(0.6f).height(14.dp).clip(RoundedCornerShape(4.dp)).background(c))
                }
                Box(Modifier.size(100.dp, 72.dp).clip(RoundedCornerShape(8.dp)).background(c))
            }
        }
    }
}
