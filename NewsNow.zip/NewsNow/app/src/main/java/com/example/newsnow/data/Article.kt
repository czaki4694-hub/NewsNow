package com.example.newsnow.data

data class Article(
    val title: String,
    val link: String,
    val image: String?,
    val source: String,
    val time: Long,
    val summary: String,
)

fun timeAgo(t: Long): String {
    if (t <= 0) return ""
    val m = (System.currentTimeMillis() - t) / 60_000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "قبل $m دقيقة"
        m < 1440 -> "قبل ${m / 60} ساعة"
        else -> "قبل ${m / 1440} يوم"
    }
}
