package com.example.newsnow.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsnow.data.Article
import com.example.newsnow.data.Feeds
import com.example.newsnow.data.NewsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val tab: Int = 0,
    val loading: Boolean = true,
    val items: List<Article> = emptyList(),
    val error: String? = null,
)

class NewsViewModel : ViewModel() {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state
    private var job: Job? = null

    init { load(false) }

    fun select(i: Int) {
        if (i == _state.value.tab) return
        _state.value = UiState(tab = i, loading = true)
        load(false)
    }

    fun load(force: Boolean) {
        job?.cancel()
        val tab = _state.value.tab
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val items = NewsRepository.load(Feeds.categories[tab], force)
                _state.update { it.copy(loading = false, items = items) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "حدث خطأ") }
            }
        }
    }
}
