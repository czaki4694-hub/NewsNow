package com.example.newsnow.data

data class Source(val name: String, val url: String, val google: Boolean = false)
data class Category(val title: String, val sources: List<Source>)

object Feeds {
    private fun g(topic: String) = Source(
        "Google News",
        "https://news.google.com/rss/headlines/section/topic/$topic?hl=ar&gl=SA&ceid=SA:ar",
        google = true,
    )

    // مصادر عربية مباشرة (تحتوي صوراً)
    val aljazeera = Source("الجزيرة", "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdc1c4b0e1a")
    val bbc = Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml")
    val sky = Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss")
    val france24 = Source("فرانس 24", "https://www.france24.com/ar/rss")
    val dw = Source("DW عربية", "https://rss.dw.com/xml/rss-ar-all")
    val alarabiya = Source("العربية", "https://www.alarabiya.net/feed/rss2/ar.xml")

    /** مصادر الإشعارات العاجلة */
    val breaking = listOf(aljazeera, bbc, sky, france24)

    val categories = listOf(
        Category("الرئيسية", listOf(aljazeera, bbc, sky, france24, dw, alarabiya)),
        Category("عالمي", listOf(g("WORLD"))),
        Category("اقتصاد", listOf(g("BUSINESS"))),
        Category("رياضة", listOf(g("SPORTS"))),
        Category("تقنية", listOf(g("TECHNOLOGY"))),
        Category("علوم", listOf(g("SCIENCE"))),
        Category("صحة", listOf(g("HEALTH"))),
        Category("ترفيه", listOf(g("ENTERTAINMENT"))),
    )
}
