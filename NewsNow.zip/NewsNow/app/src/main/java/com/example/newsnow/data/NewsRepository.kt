package com.example.newsnow.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

object NewsRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
    private val cache = ConcurrentHashMap<String, Pair<Long, List<Article>>>()

    suspend fun load(cat: Category, force: Boolean): List<Article> {
        val c = cache[cat.title]
        if (!force && c != null && System.currentTimeMillis() - c.first < 5 * 60_000) return c.second
        val list = coroutineScope {
            cat.sources.map { s ->
                async(Dispatchers.IO) { runCatching { fetch(s) }.getOrDefault(emptyList()) }
            }.awaitAll()
        }.flatten().distinctBy { it.link }.sortedByDescending { it.time }.take(80)
        if (list.isEmpty()) throw IOException("تعذر جلب الأخبار، تحقق من الاتصال")
        cache[cat.title] = System.currentTimeMillis() to list
        return list
    }

    /** blocking: استدعِها من خيط خلفي */
    fun fetch(s: Source): List<Article> {
        val req = Request.Builder().url(s.url).header("User-Agent", "Mozilla/5.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            return RssParser.parse(r.body!!.string(), s.name, s.google)
        }
    }
}
