package com.example.newsnow.work

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.newsnow.data.Article
import com.example.newsnow.data.Feeds
import com.example.newsnow.data.NewsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class BreakingWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val prefs = ctx.getSharedPreferences("news", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notify", true)) return@withContext Result.success()

        val items = Feeds.breaking
            .flatMap { runCatching { NewsRepository.fetch(it) }.getOrDefault(emptyList()) }
            .sortedByDescending { it.time }
        if (items.isEmpty()) return@withContext Result.success()

        val seen = prefs.getStringSet("seen", emptySet()) ?: emptySet()
        val firstRun = seen.isEmpty()
        val recent = System.currentTimeMillis() - 3 * 3_600_000
        if (!firstRun) {
            items.filter { it.link !in seen && it.time > recent }.take(3).forEach { notify(it) }
        }
        prefs.edit().putStringSet("seen", (items.map { it.link } + seen).take(300).toSet()).apply()
        Result.success()
    }

    @SuppressLint("MissingPermission")
    private fun notify(a: Article) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val pi = PendingIntent.getActivity(
            ctx, a.link.hashCode(), Intent(Intent.ACTION_VIEW, Uri.parse(a.link)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("عاجل • ${a.source}")
            .setContentText(a.title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.title))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(a.link.hashCode(), n)
    }

    companion object { const val CHANNEL = "breaking" }
}
