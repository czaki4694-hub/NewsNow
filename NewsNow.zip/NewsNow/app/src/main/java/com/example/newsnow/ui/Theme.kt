package com.example.newsnow.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFFFF5A4F),
    background = Color(0xFF101114),
    surface = Color(0xFF101114),
    surfaceVariant = Color(0xFF22242A),
    onBackground = Color(0xFFF2F2F2),
    onSurface = Color(0xFFF2F2F2),
    onSurfaceVariant = Color(0xFFA6A8B0),
)

@Composable
fun NewsTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)
