package com.example.newsnow.data

import android.text.Html
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale

object RssParser {
    private val formats = listOf(
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
    )
    private val imgRegex = Regex("<img[^>]+src=[\"']([^\"']+)")

    private fun parseDate(s: String): Long {
        for (f in formats) {
            val t = runCatching { SimpleDateFormat(f, Locale.ENGLISH).parse(s.trim())!!.time }.getOrNull()
            if (t != null) return t
        }
        return 0L
    }

    fun parse(xml: String, sourceName: String, google: Boolean): List<Article> {
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        val out = mutableListOf<Article>()
        var inItem = false
        var title = ""; var link = ""; var date = ""; var desc = ""
        var img: String? = null; var src = sourceName
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name
                if (n == "item" || n == "entry") {
                    inItem = true; title = ""; link = ""; date = ""; desc = ""; img = null; src = sourceName
                } else if (inItem) when (n) {
                    "title" -> title = p.nextText()
                    "link" -> {
                        val h = p.getAttributeValue(null, "href")
                        link = if (!h.isNullOrBlank()) h else p.nextText()
                    }
                    "pubDate", "published", "updated", "dc:date" -> date = p.nextText()
                    "description", "summary" -> desc = p.nextText()
                    "source" -> if (google) src = p.nextText()
                    "media:thumbnail", "media:content", "enclosure" -> {
                        val u = p.getAttributeValue(null, "url")
                        val t = p.getAttributeValue(null, "type")
                        if (img == null && !u.isNullOrBlank() && (t == null || t.startsWith("image"))) img = u
                    }
                }
            } else if (ev == XmlPullParser.END_TAG && inItem && (p.name == "item" || p.name == "entry")) {
                inItem = false
                if (title.isNotBlank() && link.isNotBlank()) {
                    val image = img ?: imgRegex.find(desc)?.groupValues?.get(1)
                    val summary = if (google) "" else
                        Html.fromHtml(desc, Html.FROM_HTML_MODE_COMPACT).toString().trim().take(140)
                    val clean = Html.fromHtml(title, Html.FROM_HTML_MODE_COMPACT).toString().trim()
                        .removeSuffix(" - $src").trim()
                    out.add(Article(clean, link.trim(), image, src, parseDate(date), summary))
                }
            }
            ev = p.next()
        }
        return out
    }
}
